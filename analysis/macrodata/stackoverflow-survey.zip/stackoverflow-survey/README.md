This folder is empty in the git repository. It's data is in ../stackoverflow-survey.zip.
